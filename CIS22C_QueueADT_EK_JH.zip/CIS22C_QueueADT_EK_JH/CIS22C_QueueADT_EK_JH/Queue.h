#pragma once
#include "List.h"

template <class ObjectType>
class Queue : protected List<ObjectType> {
public:
	Queue() {}

	void enqueue(ObjectType obj) {
		addFirst(obj);
	}

	ObjectType dequeue() {
		ObjectType temp = findSelect(listSize());
		removeSelect(listSize());
		return temp;
	}

	ObjectType front()
	{
		return findSelect(listSize());
	}

	ObjectType back() {
		return findSelect(0);
	}

	void empty() {
		clearList();
	}
};