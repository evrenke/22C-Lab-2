#pragma once
#include "List.h"

template <class ObjectType>
class Stack : protected List<ObjectType>
{
public:
	Stack() {}
	~Stack() {}
	void push(ObjectType ot)
	{
		addLast(ot);
	}
	bool pop()
	{
		return removeSelect(listSize());
	}
	ObjectType peek()
	{
		return findSelect(listSize());
	}
	bool isEmpty()
	{
		return listSize() == 0;
	}
};
